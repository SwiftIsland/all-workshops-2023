//
//  ImmersiveView.swift
//  visionOS WorkShopo
//
//  Created by Jordi Bruin on 01/09/2023.
//

import SwiftUI
import RealityKit

struct ImmersiveView: View {
    var body: some View {
        Text("TEST")
    }
}

#Preview {
    ImmersiveView()
}

